<?php
include_once 'class_cliente.php';
$disc       = new regCliente();
echo $disc->listCliente();
?>