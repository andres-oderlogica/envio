<?php
header("Location: ../docente/registro_docente.php");
?>